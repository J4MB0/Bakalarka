using UnityEngine;
using UnityEngine.InputSystem;
public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float jumpForce;
    [SerializeField] private LayerMask groundLayer;
    
    private Rigidbody2D body;
    private Animator anim;
    private BoxCollider2D boxCollider;
    private float horizontalInput;

    private InputActions _input;

    private void Awake()
{
    //Grab references for rigidbody and animator from object
    body = GetComponent<Rigidbody2D>();
    anim = GetComponent<Animator>();
    boxCollider = GetComponent<BoxCollider2D>();
}

private void OnEnable()
{
    _input = new InputActions();
    _input.Player_Input.Jump.performed += Jump;
    _input.Player_Input.Movement.Enable();
    _input.Player_Input.Jump.Enable();
}

private void OnDisable()
{
    _input.Player_Input.Jump.performed -= Jump;
    _input.Player_Input.Movement.Disable();
    _input.Player_Input.Jump.Disable();
}

private void Update()
{   
    horizontalInput = _input.Player_Input.Movement.ReadValue<float>();
    body.velocity = new Vector2(horizontalInput * speed, body.velocity.y);

    //Flip player when moving left-right
    if (horizontalInput > 0.01f)
        transform.localScale = Vector3.one;
    else if (horizontalInput < -0.01f)
        transform.localScale = new Vector3(-1, 1, 1);


    //Set animator parameters
    anim.SetBool("run", horizontalInput != 0);
    anim.SetBool("grounded", isGrounded());

}

    private void Jump(InputAction.CallbackContext context)
{   
    if (isGrounded()){
    body.velocity = new Vector2(body.velocity.x, jumpForce);
    anim.SetTrigger("jump");
    }
}


private bool isGrounded()
{
    RaycastHit2D raycastHit = Physics2D.BoxCast(boxCollider.bounds.center, boxCollider.bounds.size, 0, Vector2.down, 0.1f, groundLayer);
    return raycastHit.collider != null;
}

public bool canAttack()
{
    return horizontalInput == 0 && isGrounded();
}

}
