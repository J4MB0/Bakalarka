using UnityEngine;
using System.Collections;

public class EnemyAI : MonoBehaviour
{
    [SerializeField] private float detectionRange = 5f;        // Dosah detekcie (chase range)
    [SerializeField] private float attackRange = 1.5f;           // Dosah, v ktorom sa spustí útok
    [SerializeField] private float moveSpeed = 2f;
    [SerializeField] private float attackCooldown = 2f;          // Cooldown medzi útokmi
    [SerializeField] private float attackDamage = 10f;           // Nastaviteľný damage

    // Nové premenne pre dash
    [SerializeField] private float attackDashSpeed = 4f;         // Rýchlosť dashu pri útoku
    [SerializeField] private float attackDashDistance = 2f;        // Vzdialenosť, ktorú dash prekryje

    [SerializeField] private LayerMask playerLayer;
    [SerializeField] private LayerMask groundLayer;            

    private Animator anim;
    private Transform player;
    private Rigidbody2D rb;

    private bool isSleeping = false;
    private bool isAttacking = false;
    private bool isWaking = false;
    private bool canDealDamage = false; // Damage sa udeľuje len počas attack okna

    private Coroutine sleepCoroutine;
    private Coroutine wakeCoroutine;
    private Coroutine attackCoroutine;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        player = GameObject.FindGameObjectWithTag("Player")?.transform;
    }

    private void Update()
    {
        if (player == null)
            return;

        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        if (distanceToPlayer < attackRange)
        {
            // Hráč je v útokovom dosahu
            if (isSleeping)
            {
                if (!isWaking && wakeCoroutine == null)
                    wakeCoroutine = StartCoroutine(WakeSequence(0.5f, 0.5f));
            }
            else
            {
                if (!isAttacking && !isWaking && attackCoroutine == null)
                    attackCoroutine = StartCoroutine(AttackSequence());
            }
            StopMoving();
        }
        else if (distanceToPlayer < detectionRange)
        {
            // Hráč je detegovaný, ale nie v útokovom dosahu – prenasledujeme ho
            if (!isSleeping)
            {
                if (!isWaking && attackCoroutine == null)
                    MoveTowardsPlayer();
            }
            // Zrušíme prebiehajúce útokové či wake sequence
            if (attackCoroutine != null)
            {
                StopCoroutine(attackCoroutine);
                attackCoroutine = null;
                isAttacking = false;
                canDealDamage = false;
            }
            if (wakeCoroutine != null)
            {
                StopCoroutine(wakeCoroutine);
                wakeCoroutine = null;
                isWaking = false;
            }
            if (sleepCoroutine != null)
            {
                StopCoroutine(sleepCoroutine);
                sleepCoroutine = null;
            }
        }
        else
        {
            // Hráč nie je detegovaný – spusti sa čakanie 2 sekúnd na prechod do spánkového režimu
            if (!isSleeping && sleepCoroutine == null)
                sleepCoroutine = StartCoroutine(SleepAfterDelay(2f));
            StopMoving();
            if (wakeCoroutine != null)
            {
                StopCoroutine(wakeCoroutine);
                wakeCoroutine = null;
                isWaking = false;
            }
            if (attackCoroutine != null)
            {
                StopCoroutine(attackCoroutine);
                attackCoroutine = null;
                isAttacking = false;
                canDealDamage = false;
            }
        }
    }

    private IEnumerator SleepAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        GoToSleep();
        sleepCoroutine = null;
    }

    // WakeSequence s oneskorením pred aj po prebudení
    private IEnumerator WakeSequence(float preDelay, float postDelay)
    {
        isWaking = true;
        yield return new WaitForSeconds(preDelay);
        if (isSleeping)
            WakeUp();
        yield return new WaitForSeconds(postDelay);
        isWaking = false;
        wakeCoroutine = null;
    }

    // Útoková sekvencia: spustí útok animáciu, spustí dash, nastaví damage okno na 0,61 s a potom čaká zvyšok cooldownu.
    private IEnumerator AttackSequence()
    {
        isAttacking = true;
        StopMoving();
        anim.SetTrigger("attack");

        // Spustenie dashu súbežne s útokom
        StartCoroutine(AttackDash());

        // Aktivácia damage okna
        canDealDamage = true;
        yield return new WaitForSeconds(0.61f);
        canDealDamage = false;

        // Zvyšok cooldownu
        yield return new WaitForSeconds(attackCooldown);
        isAttacking = false;
        attackCoroutine = null;
    }

    // Coroutine na dash: nepriateľ sa posúva dashom v smere, do ktorého je otočený.
    private IEnumerator AttackDash()
    {
        // Určíme smer dashu na základe lokálnej škály (ak scale.x > 0, dash doprava, inak doleva)
        Vector2 dashDirection = transform.localScale.x > 0 ? Vector2.right : Vector2.left;
        float dashDuration = attackDashDistance / attackDashSpeed;
        float timer = 0f;
        while (timer < dashDuration)
        {
            rb.velocity = new Vector2(dashDirection.x * attackDashSpeed, rb.velocity.y);
            timer += Time.deltaTime;
            yield return null;
        }
        // Po dashi zastavíme horizontálny pohyb
        rb.velocity = new Vector2(0, rb.velocity.y);
    }

    private void GoToSleep()
    {
        isSleeping = true;
        isAttacking = false;
        StopMoving();
        anim.SetTrigger("sleep");
    }

    private void WakeUp()
    {
        if (isSleeping)
        {
            isSleeping = false;
            anim.SetTrigger("wake up");
        }
    }

    private void MoveTowardsPlayer()
    {
        if (player == null)
            return;

        anim.SetBool("walking", true);
        Vector2 direction = (player.position - transform.position).normalized;
        rb.velocity = new Vector2(direction.x * moveSpeed, rb.velocity.y);

        // Otáčanie nepriateľa podľa smeru pohybu
        if (direction.x > 0)
            transform.localScale = new Vector3(1, 1, 1);
        else if (direction.x < 0)
            transform.localScale = new Vector3(-1, 1, 1);
    }

    private void StopMoving()
    {
        anim.SetBool("walking", false);
        rb.velocity = new Vector2(0, rb.velocity.y);
    }

    // Verejné metódy pre DamageZone (child skript)
    public bool CanDealDamage() { return canDealDamage; }
    public float GetAttackDamage() { return attackDamage; }
    public void DisableDamage() { canDealDamage = false; }
}
