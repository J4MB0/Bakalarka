using UnityEngine;

public class EnemyDamageZone : MonoBehaviour
{
    private EnemyAI enemyAI;

    private void Awake()
    {
        // Získame referenciu na rodičovský EnemyAI skript
        enemyAI = GetComponentInParent<EnemyAI>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Skontrolujeme, či kolidujúci objekt je hráč
        if (collision.CompareTag("Player") && enemyAI != null)
        {
            // Ak je útok aktívny a damage okno je otvorené, udeľ damage
            if (enemyAI.CanDealDamage())
            {
                collision.GetComponent<Health>()?.TakeDamage(enemyAI.GetAttackDamage());
                enemyAI.DisableDamage();
            }
        }
    }
}
