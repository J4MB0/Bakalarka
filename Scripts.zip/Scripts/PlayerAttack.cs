using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

public class PlayerAttack : MonoBehaviour
{
    [Header("Attack Timing")]
    [SerializeField] private float attackCooldown = 1f; // Cooldown medzi útokmi

    [Header("Attack Damage Parameters")]
    [SerializeField] private int attackDamage = 10; // Damage, ktorý hráč udeľuje
    [SerializeField] private Transform attackPoint; // Pozícia, odkiaľ sa vyhodnocuje útok
    [SerializeField] private Vector2 attackBoxSize = new Vector2(1f, 1f); // Rozmery oblasti útoku
    [SerializeField] private LayerMask enemyLayer; // Vrstva nepriateľov

    private Animator anim;
    private PlayerMovement playerMovement;
    private float cooldownTimer = Mathf.Infinity;
    private InputActions _input; // Generovaná trieda z Input Actions assetu
    public bool HaveWeapon = false;
    private void Awake()
    {
        anim = GetComponent<Animator>();
        playerMovement = GetComponent<PlayerMovement>();
    }

    private void OnEnable()
    {
        _input = new InputActions();
        _input.Enable(); // Aktivujeme všetky akcie
        _input.Player_Input.Attack.performed += Attack;
    }

    private void OnDisable()
    {
        _input.Player_Input.Attack.performed -= Attack;
        _input.Disable();
    }

    private void Update()
    {
        cooldownTimer += Time.deltaTime;
    }

    // Metóda volaná pri útoku
    private void Attack(InputAction.CallbackContext context)
    {
        if (context.performed && cooldownTimer > attackCooldown && playerMovement.canAttack() && HaveWeapon)
        {
            anim.SetTrigger("attack");
            cooldownTimer = 0;
            StartCoroutine(CallDamageAfterDelay(0.3f)); // Oneskoď podľa potreby
        }
    }

    private IEnumerator CallDamageAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        DamageEnemies();
    }

    // Táto metóda vyhľadá nepriateľov v attack oblasti a udelí im damage
    public void DamageEnemies()
    {
        Collider2D[] hitEnemies = Physics2D.OverlapBoxAll(attackPoint.position, attackBoxSize, 0, enemyLayer);
        foreach (Collider2D enemy in hitEnemies)
        {
            EnemyHealth enemyHealth = enemy.GetComponent<EnemyHealth>();
            if (enemyHealth != null)
            {
                enemyHealth.TakeDamage(attackDamage);
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        if (attackPoint == null)
            return;
        Gizmos.color = Color.red;
        Gizmos.DrawWireCube(attackPoint.position, attackBoxSize);
    }
}
