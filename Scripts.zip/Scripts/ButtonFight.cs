using UnityEngine;

public class ButtonFight : MonoBehaviour
{
    void Start()
    {
        gameObject.SetActive(false);
    }
    public void Activation()
    {
        gameObject.SetActive(true);
    }
}
