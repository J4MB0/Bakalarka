using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    [SerializeField] private float startingHealth = 1f; // Počiatočné zdravie nepriateľa
    public float currentHealth { get; private set; }
    
    private Animator anim;
    private Rigidbody2D rb;
    

    private void Awake()
    {
        currentHealth = startingHealth;
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
    }

    public void TakeDamage(float damage)
    {
        currentHealth = Mathf.Clamp(currentHealth - damage, 0, startingHealth);

        if (currentHealth > 0)
        {
            anim.SetTrigger("hurt");

            // Voliteľný knockback efekt:
            //float direction = transform.localScale.x > 0 ? -1 : 1;
            //rb.velocity = new Vector2(direction * 5, 5);
        }
        else
        {
            Die();
        }
    }

    private void Die()
    {
        rb.velocity = Vector2.zero;
        anim.SetTrigger("die");
        Destroy(gameObject, 0.31f);
    }
    
}
