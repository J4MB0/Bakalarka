using UnityEngine;
using System.Collections;
public class Health : MonoBehaviour
{
    [SerializeField] private float startingHealth;
    public float currentHealth { get; private set; }
    private Animator anim;
    private Rigidbody2D body; // Pridaný Rigidbody2D pre knockback efekt
    private bool alive = true;
    private void Awake()
    {
        currentHealth = startingHealth;
        anim = GetComponent<Animator>();
        body = GetComponent<Rigidbody2D>(); // Získanie referencie na Rigidbody2D
    }

    public void TakeDamage(float _damage)
    {
        currentHealth = Mathf.Clamp(currentHealth - _damage, 0, startingHealth);

        if (currentHealth > 0)
        {
            anim.SetTrigger("hurt");

            // Knockback efekt (smer podľa otočenia)
            float direction = transform.localScale.x > 0 ? -1 : 1; // Určí smer knockbacku
            body.velocity = new Vector2(direction * 5, 5); // Knockback dozadu + mierny výskok
        }
        if (currentHealth == 0 && alive)
        {
            alive = false;
            body.velocity = Vector2.zero;
            anim.SetTrigger("die");
            GetComponent<PlayerMovement>().enabled = false;
            StartCoroutine(DeactivateAfterDelay(5f));
        }
    }
    private IEnumerator DeactivateAfterDelay(float delay)
{
    yield return new WaitForSeconds(delay);
    gameObject.SetActive(false);
}

    public void AddHealth(float _value)
    {
        currentHealth = Mathf.Clamp(currentHealth + _value, 0, startingHealth);
    }

}
