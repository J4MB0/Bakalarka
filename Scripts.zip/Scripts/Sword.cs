using UnityEngine;

public class Sword : MonoBehaviour
{

    [SerializeField] private ButtonFight buttonFight;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            PlayerAttack playerAttack = collision.GetComponent<PlayerAttack>();
            playerAttack.HaveWeapon = true;
            buttonFight.Activation();
            gameObject.SetActive(false);
        }
    }
}
